
<?php $__env->startSection('nabvar'); ?>
<?php $__env->startSection('menu'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('cont'); ?>

<h1>Albúns:</h1>

<?php $__currentLoopData = $album -> musicas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $musica): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<h3><?php echo e($musica->titulo); ?></h3>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__currentLoopData = $musica->musicos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $musico): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<b>ID: <?php echo e($album->id_album); ?></b><br>
<b>Título: <?php echo e($album->titulo); ?></b><br>
<b>ID Gênero: <?php echo e($album->id_genero); ?></b><br>
<b>Nome Músico: <?php echo e($musico->nome); ?></b><br>
<b>Data Lançamento: <?php echo e($album->data_lancamento); ?></b><br>
<b>Observações: <?php echo e($album->observacoes); ?></b>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('rodapé'); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Gabriel\PSI\ProjetoM18\ProjetoM18\resources\views/albuns/show.blade.php ENDPATH**/ ?>