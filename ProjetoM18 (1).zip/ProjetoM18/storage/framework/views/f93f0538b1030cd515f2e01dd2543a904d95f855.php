
<h1>Musico:</h1>

<?php $__currentLoopData = $musica->musicos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $musico): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<h3><?php echo e($musico->nome); ?></h3>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<b>ID:<?php echo e($musica->id_musica); ?></b><br>
<b>Titulo:<?php echo e($musica->titulo); ?></b><br>
<b>ID Musico:<?php echo e($musica->id_musico); ?></b><br>
<b>ID Album:<?php echo e($musica->id_album); ?></b><br>
<b>ID Genero:<?php echo e($musica->id_genero); ?></b><?php /**PATH D:\PSI\ProjetoM18\resources\views/musicas/show.blade.php ENDPATH**/ ?>