<h1>Albuns:</h1>

<?php $__currentLoopData = $album -> musicas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $musica): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<h3><?php echo e($musica->titulo); ?></h3>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<b>ID:<?php echo e($album->id_album); ?></b><br>
<b>Titulo:<?php echo e($album->titulo); ?></b><br>
<b>ID Genero:<?php echo e($album->id_genero); ?></b><br>
<b>ID Musico:<?php echo e($album->id_musico); ?></b><br>
<b>Data Lancamento:<?php echo e($album->data_lancamento); ?></b><br>
<b>Observacoes:<?php echo e($album->observacoes); ?></b>
<?php /**PATH D:\PSI\ProjetoM18\resources\views/albuns/show.blade.php ENDPATH**/ ?>