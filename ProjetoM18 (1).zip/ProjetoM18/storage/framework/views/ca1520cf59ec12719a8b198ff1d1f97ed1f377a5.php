<!DOCTYPE html>
<html>
<head>
    <?php echo $__env->yieldContent('navbar'); ?>
	<meta charset="utf-8">
	<meta content="width=device-width, initial-scale=1.0, shrink-to-fit-no" name="viewport">

	<title>Exemplo de Bootsrap</title>

	<link href="css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <!--barra de navegação-->
    <nav class="navbar navbar-expand-md navbar-blue fixed-top bg-blue">
    <a class="navbar-brand" href="#">Projeto PSI M18</a>
        <button class="navbar-toggler"type="button"data-toogle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault"aria-expanded="false" aria-label="Toogle navigation">
        <span class="navbar-tooggler-icon"></span>
        </button>
        
        <div class="collapse navbar-collapse"id="navbarsExampleDefault">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('albuns.index')); ?>">Albuns</a>
            </li>
            <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('generos.index')); ?>">Generos</a>
            </li>
            <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('musicas.index')); ?>">Musicas</a>
            </li>
            <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('musicos.index')); ?>">Musicos</a>
            </li>
            </ul>
    
        </div>
    </nav>

    <?php echo $__env->yieldContent('menu'); ?>
    <main role="main">
        
    <div class="jumbotron">
        <div class="container">
             <div class="text-center">
        <h1 class="display-3">PSI Módulo 18 Projeto</h1>
            
        <p>Gabriel Pereira</p>
           
              <br>
                 <br>
        </div>
        </div>
        </div>
        
       
        <?php echo $__env->yieldContent('conteudo'); ?>
        </div>
        </div>
        <hr>
        <p align="center"><img src="1.jpg"></p>
        <?php echo $__env->yieldContent('rodapé'); ?>
       
      <br>
        </main>
     <div class="text-center">
        <footer class="container">
        <p>&copy;PSI M18</p>
        </footer>
    </div>
    
    
    <script src="js/jquery-3.5.1.min.js"></script>
<script src="js/bootstrap.js"></script>
    </body>
</html><?php /**PATH D:\PSI\ProjetoM18\resources\views/layout.blade.php ENDPATH**/ ?>