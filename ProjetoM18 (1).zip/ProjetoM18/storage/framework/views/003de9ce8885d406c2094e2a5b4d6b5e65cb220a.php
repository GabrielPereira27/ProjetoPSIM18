
<?php $__env->startSection('nabvar'); ?>
<?php $__env->startSection('menu'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('cont'); ?>
<h1>Musico:</h1>

<?php $__currentLoopData = $musica->musicos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $musico): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<h3><?php echo e($musico->nome); ?></h3>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<b>ID:<?php echo e($musica->id_musica); ?></b><br>
<b>Titulo:<?php echo e($musica->titulo); ?></b><br>
<b>ID Musico:<?php echo e($musica->id_musico); ?></b><br>
<b>ID Album:<?php echo e($musica->id_album); ?></b><br>
<b>ID Genero:<?php echo e($musica->id_genero); ?></b>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('rodapé'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Gabriel\PSI\ProjetoM18\ProjetoM18\resources\views/musicas/show.blade.php ENDPATH**/ ?>