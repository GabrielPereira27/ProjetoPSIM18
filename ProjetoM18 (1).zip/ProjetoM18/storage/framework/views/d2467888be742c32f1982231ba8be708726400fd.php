
<h1>Musico:</h1>

<?php $__currentLoopData = $musico->musicas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $musica): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<h3><?php echo e($musico->nome); ?></h3>

<b>ID:<?php echo e($musica->id_musica); ?></b><br>
<b>Titulo:<?php echo e($musica->titulo); ?></b><br>
<b>ID Musico:<?php echo e($musica->id_musico); ?></b><br>
<b>ID Genero:<?php echo e($musica->id_genero); ?></b><br>
<b>Nacionalidade:<?php echo e($musica->nacionalidade); ?></b><br>
<b>Data Nascimento:<?php echo e($musica->data_nascimento); ?></b>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php /**PATH D:\PSI\ProjetoM18\resources\views/musicos/show.blade.php ENDPATH**/ ?>