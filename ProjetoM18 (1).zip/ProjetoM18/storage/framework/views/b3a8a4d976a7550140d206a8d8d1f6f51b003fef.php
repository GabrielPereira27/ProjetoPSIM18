
<?php $__env->startSection('nabvar'); ?>
<?php $__env->startSection('menu'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>
<ul>
<?php $__currentLoopData = $musicas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $musica): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li>
<a href="<?php echo e(route('musicas.show', ['id'=>$musica->id_musica])); ?>">
    <?php echo e($musica->titulo); ?></a></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php echo e($musicas->render()); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('rodapé'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PSI\ProjetoM18\resources\views/musicas/index.blade.php ENDPATH**/ ?>