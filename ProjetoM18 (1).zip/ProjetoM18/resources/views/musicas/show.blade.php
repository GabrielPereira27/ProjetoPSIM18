@extends('layout')
@section('nabvar')
@section('menu')
@endsection

@section('cont')
<h1>Musico:</h1>

@foreach($musica->musicos as $musico)
<h3>{{$musico->nome}}</h3>
@endforeach

<b>ID:{{$musica->id_musica}}</b><br>
<b>Titulo:{{$musica->titulo}}</b><br>
<b>ID Musico:{{$musica->id_musico}}</b><br>
<b>ID Album:{{$musica->id_album}}</b><br>
<b>ID Genero:{{$musica->id_genero}}</b>
@endsection
@section('rodapé')

@endsection