@extends('layout')
@section('nabvar')
@section('menu')
@endsection

@section('cont')
<ul>
@foreach($musicas as $musica)
<li>
<a href="{{route('musicas.show', ['id'=>$musica->id_musica])}}">
    {{$musica->titulo}}</a></li>
@endforeach
</ul>
{{$musicas->render()}}
@endsection

@section('rodapé')

@endsection
