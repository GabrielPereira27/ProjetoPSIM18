@extends('layout')
@section('nabvar')
@section('menu')
@endsection

@section('cont')
<ul>
@foreach($albuns as $album)
<li>
<a href="{{route('albuns.show', ['id' =>$album ->id_album])}}">
    {{$album->titulo}}</a></li>
@endforeach
</ul>
{{$albuns->render()}}
@endsection

@section('rodapé')

@endsection