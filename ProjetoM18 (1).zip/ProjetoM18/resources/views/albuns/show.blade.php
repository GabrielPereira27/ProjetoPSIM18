@extends('layout')
@section('nabvar')
@section('menu')
@endsection

@section('cont')

<h1>Albúns:</h1>

@foreach($album -> musicas as $musica)
<h3>{{$musica->titulo}}</h3>
@endforeach
@foreach($musica->musicos as $musico)
@endforeach

<b>ID: {{$album->id_album}}</b><br>
<b>Título: {{$album->titulo}}</b><br>
<b>ID Gênero: {{$album->id_genero}}</b><br>
<b>Nome Músico: {{$musico->nome}}</b><br>
<b>Data Lançamento: {{$album->data_lancamento}}</b><br>
<b>Observações: {{$album->observacoes}}</b>
@endsection
@section('rodapé')

@endsection

