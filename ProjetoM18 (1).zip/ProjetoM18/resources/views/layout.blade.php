<!DOCTYPE html>
<html>
<head>
    @yield('navbar')
	<meta charset="utf-8">
	<meta content="width=device-width, initial-scale=1.0, shrink-to-fit-no" name="viewport">

	<title>Projeto PSI | Gabriel</title>

	<link rel="stylesheet" type="text/css" href="{{asset('css/bootstrap.min.css')}}" rel="stylesheet">
    <script src="{{asset('js/jquery-3.5.1.min.js')}}" type="text/javascript"></script>
    <script src="{{asset('js/bootstrap.min.js')}}" type="text/javascript"></script>
</head>

<body>
    <!--barra de navegação-->
    <nav class="navbar navbar-expand-md navbar-blue fixed-top bg-blue">
    <a class="navbar-brand" href="#"><b>Projeto PSI M18</b></a>
        <button class="navbar-toggler"type="button"data-toogle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault"aria-expanded="false" aria-label="Toogle navigation">
        <span class="navbar-tooggler-icon"></span>
        </button>
        
        <div class="collapse navbar-collapse"id="navbarsExampleDefault">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item">
            <a class="nav-link" href="{{route('albuns.index')}}"><b>Albuns</b></a>
            </li>
            <li class="nav-item">
            <a class="nav-link" href="{{route('generos.index')}}"><b>Generos</b></a>
            </li>
            <li class="nav-item">
            <a class="nav-link" href="{{route('musicas.index')}}"><b>Musicas</b></a>
            </li>
            <li class="nav-item">
            <a class="nav-link" href="{{route('musicos.index')}}"><b>Musicos</b></a>
            </li>
            </ul>
    
        </div>
    </nav>

    @yield('menu')
    <main role="main">
        
    <div class="jumbotron">
        <div class="container">
             <div class="text-center">
        <h1 class="display-3"><b>PSI Módulo 18 Projeto</b></h1>
            
        <p><b>Gabriel Pereira</b></p>
           
              <br>
                 <br>
        </div>
        </div>
        </div>
        
       
        @yield('cont')
        </div>
        </div>
        <hr>
        
        @yield('rodapé')
        <p align="center"><img src="{{URL::to('/img/1.jpg')}}" ></p>
      <br>
        </main>
     <div class="text-center">
        <footer class="container">
        <p><b>&copy;PSI M18</b></p>
        </footer>
    </div>
    
    

    </body>
</html>