@extends('layout')
@section('nabvar')
@section('menu')
@endsection

@section('cont')
<ul>
@foreach($generos as $genero)
<li>
<a href="{{route('generos.show', ['id' =>$genero ->id_genero])}}">
    {{$genero->designacao}}</a></li>
@endforeach
</ul>
{{$generos->render()}}
@endsection

@section('rodapé')

@endsection
