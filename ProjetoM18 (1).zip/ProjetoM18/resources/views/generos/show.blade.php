@extends('layout')
@section('nabvar')
@section('menu')
@endsection

@section('cont')
<h1>Generos:</h1>

@foreach($genero -> musicas as $musica)
<h3>{{$genero->designacao}}</h3>
@endforeach
@foreach($musica->musicos as $musico)
@endforeach

<b>ID: {{$musica->id_musica}}</b><br>
<b>Título: {{$musica->titulo}}</b><br>
<b>Nome Músico: {{$musico->nome}}</b><br>
<b>ID Album: {{$musica->id_album}}</b><br>
<b>ID Genero: {{$musica->id_genero}}</b>
@endsection
@section('rodapé')

@endsection