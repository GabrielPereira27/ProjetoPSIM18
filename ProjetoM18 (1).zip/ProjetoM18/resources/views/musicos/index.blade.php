@extends('layout')
@section('nabvar')
@section('menu')
@endsection

@section('cont')
<ul>
@foreach($musicos as $musico)
<li>
<a href="{{route('musicos.show', ['id' =>$musico ->id_musico])}}">
    {{$musico->nome}}</a></li>
@endforeach
</ul>
{{$musicos->render()}}
@endsection

@section('rodapé')

@endsection
