@extends('layout')
@section('nabvar')
@section('menu')
@endsection

@section('cont')
<h1>Musico:</h1>

@foreach($musico->musicas as $musica)
<h3>{{$musico->nome}}</h3>

<b>ID:{{$musica->id_musica}}</b><br>
<b>Titulo:{{$musica->titulo}}</b><br>
<b>ID Musico:{{$musica->id_musico}}</b><br>
<b>ID Genero:{{$musica->id_genero}}</b><br>
<b>Nacionalidade:{{$musico->nacionalidade}}</b><br>
<b>Data Nascimento:{{$musico->data_nascimento}}</b>
@endforeach
@endsection
@section('rodapé')

@endsection
